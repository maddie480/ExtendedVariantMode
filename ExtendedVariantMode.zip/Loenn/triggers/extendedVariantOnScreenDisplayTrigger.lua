local trigger = {}

trigger.name = "ExtendedVariantMode/ExtendedVariantOnScreenDisplayTrigger"
trigger.placements = {
    name = "trigger",
    data = {
        enable = true
    }
}

return trigger
