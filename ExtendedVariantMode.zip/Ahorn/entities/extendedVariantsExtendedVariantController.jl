﻿module ExtendedVariantModeExtendedVariantController

using ..Ahorn, Maple

# obsolete
@mapdef Entity "ExtendedVariantMode/ExtendedVariantController" ExtendedVariantController(x::Integer, y::Integer, variantChange::String="Gravity", enable::Bool=true, newValue::Integer=10, revertOnLeave::Bool=false)

end
